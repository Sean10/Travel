#include "ihead.h"
using namespace std;

void OutMap()
{
    ;
}
