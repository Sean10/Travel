#ifndef RUNNING
#define RUNNING

#include <QObject>

class Running: public QObject
{
    Q_OBJECT
public:
    Running();
    ~Running();
};

#endif // RUNNING

