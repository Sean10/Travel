#ifndef INPUTREQ
#define INPUTREQ

#include <QObject>

class InputReq: public QObject
{
    Q_OBJECT
public:
    InputReq();
    ~InputReq();

};

#endif // INPUTREQ

